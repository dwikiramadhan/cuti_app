$(function () {
    "use strict";
    $('#mainTable').editableTableWidget();
});