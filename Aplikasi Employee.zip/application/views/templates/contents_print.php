<?php
include('header.php');
echo $contents;
include('footer.php');
?>