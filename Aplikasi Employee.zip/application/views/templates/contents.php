<?php
include('header.php');
include('bar.php');
echo $contents;
include('footer.php');
?>